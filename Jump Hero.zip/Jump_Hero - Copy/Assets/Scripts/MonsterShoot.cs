using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MonsterShoot : MonoBehaviour
{
    public GameObject bullet;
    public float shootInterval = 1f; // Interval between bullet spawns
    public float bulletSpeed = 5f; // Speed of the bullets

    private bool faceLeft = false; // Variable to track the direction the monster is facing

    void Start()
    {
        StartCoroutine(ShootBullets());
        StartCoroutine(ChangeDirection());
    }

    IEnumerator ShootBullets()
    {
        while (true)
        {
            GameObject newBullet = Instantiate(bullet, transform.position, Quaternion.identity);
            Rigidbody2D bulletRigidbody = newBullet.GetComponent<Rigidbody2D>();

            if (faceLeft)
            {
                bulletRigidbody.velocity = Vector2.left * bulletSpeed;
            }
            else
            {
                bulletRigidbody.velocity = Vector2.right * bulletSpeed;
            }

            yield return new WaitForSeconds(shootInterval);

            Destroy(newBullet);
        }
    }

    IEnumerator ChangeDirection()
    {
        while (true)
        {
            yield return new WaitForSeconds(2f); // Wait for 2 seconds

            // Flip the direction the monster faces
            faceLeft = !faceLeft;

            if (faceLeft)
            {
                transform.localScale = new Vector3(-1, 1, 1); // Flip the sprite to face left
            }
            else
            {
                transform.localScale = new Vector3(1, 1, 1); // Flip the sprite to face right
            }
        }
    }
}
