using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlatformGenerator : MonoBehaviour
{
    public GameObject platform;
    public GameObject spike;
    public GameObject lightningPlatform;
    public GameObject movingPlatform;
    public GameObject bird;
	public GameObject monster;

    public int numberOfPlatforms = 600;
    public float xPosition = 3.2f;
    public float minY = 2.5f;
    public float maxY = 3.5f;
    public float platformSpacing = 2.0f;

    void Start()
    {
        Vector3 spawnPosition = new Vector3();
        Vector3 spikePosition = new Vector3();
        Vector3 platformPosition = new Vector3();
        Vector3 secondPlatformPosition = new Vector3();
        Vector3 lightningPlatformPosition = new Vector3();
        Vector3 movingPlatformPosition = new Vector3();
        Vector3 birdPosition = new Vector3();
		Vector3 monsterPosition = new Vector3();

        platformPosition.y = -4f;
        secondPlatformPosition.y = -1f;
        lightningPlatformPosition.y = -3f;
        movingPlatformPosition.y = -5f;
        birdPosition.y = -5f;
		monsterPosition.y = -5f;

        for (int i = 0; i < numberOfPlatforms; i++)
        {
            spawnPosition.y += Random.Range(minY, maxY);
            spawnPosition.x = Random.Range(-xPosition, xPosition);
            Instantiate(platform, spawnPosition, Quaternion.identity);

            spikePosition.y = spawnPosition.y + 0.1f;
            spikePosition.x = spawnPosition.x + Random.Range(-0.6f, 0.6f);
            Instantiate(spike, spikePosition, Quaternion.identity);

            platformPosition.y += Random.Range(minY, maxY) + platformSpacing;
            platformPosition.x = Random.Range(-xPosition, xPosition);
            Instantiate(platform, platformPosition, Quaternion.identity);

            secondPlatformPosition.y += Random.Range(minY - 2, maxY + 2) + platformSpacing;
            secondPlatformPosition.x = Random.Range(-xPosition, xPosition);
            Instantiate(platform, secondPlatformPosition, Quaternion.identity);

            lightningPlatformPosition.y += Random.Range(minY + 10f, maxY + 30f) + platformSpacing;
            lightningPlatformPosition.x = Random.Range(-xPosition, xPosition);
            Instantiate(lightningPlatform, lightningPlatformPosition, Quaternion.identity);

            movingPlatformPosition.y += (Random.Range(minY + 3f, maxY + 5f) + platformSpacing) / 2f;
            movingPlatformPosition.x = Random.Range(-xPosition, xPosition);
            Instantiate(movingPlatform, movingPlatformPosition, Quaternion.identity);

            birdPosition.y += Random.Range(minY + 3f, maxY + 5f) + platformSpacing;
            birdPosition.x = Random.Range(-xPosition, xPosition);
            Instantiate(bird, birdPosition, Quaternion.identity);

			monsterPosition.y += Random.Range(minY + 3f, maxY + 5f) + platformSpacing;
            monsterPosition.x = Random.Range(-xPosition, xPosition);
            Instantiate(monster, monsterPosition, Quaternion.identity);
        }
    }
}
