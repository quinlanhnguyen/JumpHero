using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class ScoreCounter: MonoBehaviour
{
    public TextMeshProUGUI scoreText;
    public TextMeshProUGUI HiScoreText;
    public int score = 0;
    public int scoreModifier = 0;
    private int hiScore = 0;

    void Start()
    {
        // Load the high score from PlayerPrefs
        hiScore = PlayerPrefs.GetInt("HiScore", 0);
    }

    void Update()
    {
        score = Mathf.RoundToInt(transform.position.y) + 3 + scoreModifier;

        if (scoreText != null)
        {
            scoreText.text = "Score: " + score;

            if (score > hiScore)
            {
                // Update the high score if the current score is higher
                hiScore = score;
                PlayerPrefs.SetInt("HiScore", hiScore);
            }

            HiScoreText.text = "HiScore: " + hiScore;
        }
    }

    int getScore() {
        return score;
    }

    public void setScoreModifier(int num) {
        scoreModifier += num;
    }
}