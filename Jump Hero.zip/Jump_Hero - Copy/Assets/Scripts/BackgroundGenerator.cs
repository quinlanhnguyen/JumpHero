using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackgroundGenerator : MonoBehaviour
{
    public GameObject daylightBackground;
	public GameObject sunsetBackground;
	public GameObject nightBackground;

	public int repeatedBackgrounds = 120;
	// public float xPosition = 3.2f;
	// public float minY = 2f;
	// public float maxY = 2.7f;

	// Use this for initialization
	void Start () {

		Vector3 spawnPosition = new Vector3();
        spawnPosition.y = 0.39f;
        Instantiate(daylightBackground, spawnPosition, Quaternion.identity);
		for (int i = 0; i < repeatedBackgrounds; i++)
		{
			Instantiate(daylightBackground, spawnPosition, Quaternion.identity);
			spawnPosition.y += 16f;
			Instantiate(sunsetBackground, spawnPosition, Quaternion.identity);
			spawnPosition.y += 16f;
			Instantiate(nightBackground, spawnPosition, Quaternion.identity);
			spawnPosition.y += 16f;
		}
	}
}
