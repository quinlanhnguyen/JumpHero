using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MovingBird : MonoBehaviour
{
	public float moveSpeed = 3.0f;
    private int direction = 1;        

	void Update() {
        transform.Translate(new Vector3(moveSpeed * Time.deltaTime * direction, 0, 0));
    }

	void OnCollisionEnter2D(Collision2D collision) {
        if (collision.gameObject.tag == "Player") {
            collision.transform.parent = transform;
        }
		if (collision.gameObject.tag == "Wall") {
			direction *= -1;
            if (gameObject.tag == "Bird") {
                transform.localScale = new Vector3(-transform.localScale.x, transform.localScale.y, transform.localScale.z);
            }
		}
    }

	void OnCollisionExit2D(Collision2D collision) {
        if (collision.gameObject.tag == "Player") {
            collision.transform.parent = null;
        }
    }
}
