using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerMovement : MonoBehaviour
{
    private float horizontal;
    private float speed = 6f;
    private float jumpingPower = 16f;
    private bool isFacingRight = true;

    [SerializeField] private Rigidbody2D rb;
    [SerializeField] private Transform groundCheck;
    [SerializeField] private LayerMask groundLayer;

    [SerializeField] private AudioSource jumpSound;
    [SerializeField] private AudioSource zapSound;
    [SerializeField] private AudioSource birdHitSound;
    [SerializeField] private AudioSource bulletHitSound;

    private ScoreCounter scoreCounter; // Add a reference to the ScoreCounter script

    void Start()
    {
        AudioSource[] audioSources = GetComponents<AudioSource>();
        jumpSound = audioSources[0];
        zapSound = audioSources[1];
        birdHitSound = audioSources[2];
        bulletHitSound = audioSources[3];
        scoreCounter = FindObjectOfType<ScoreCounter>(); // Find the ScoreCounter script in the scene
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape)) {
            SceneManager.LoadScene(0);
        }

        horizontal = Input.GetAxisRaw("Horizontal");

        if (Input.GetButtonDown("Jump") && IsGrounded())
        {
            rb.velocity = new Vector2(rb.velocity.x, jumpingPower);
            jumpSound.Play();
        }

        if (Input.GetButtonUp("Jump") && rb.velocity.y > 0f)
        {
            rb.velocity = new Vector2(rb.velocity.x, rb.velocity.y * 0.5f);
        }

        Flip();
    }

    private void FixedUpdate()
    {
        rb.velocity = new Vector2(horizontal * speed, rb.velocity.y);
    }

    private bool IsGrounded()
    {
        return Physics2D.OverlapCircle(groundCheck.position, 0.2f, groundLayer);
    }

    private void Flip()
    {
        if (isFacingRight && horizontal < 0f || !isFacingRight && horizontal > 0f)
        {
            isFacingRight = !isFacingRight;
            Vector3 localScale = transform.localScale;
            localScale.x *= -1f;
            transform.localScale = localScale;
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Spike")
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }
        else if (other.tag == "LosePoints")
        {
            zapSound.Play();
            scoreCounter.setScoreModifier(-5);
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Bird")
        {
            birdHitSound.Play();
            scoreCounter.setScoreModifier(-3);
        }
        else if (collision.gameObject.tag == "Bullet")
        {
            bulletHitSound.Play();
            scoreCounter.setScoreModifier(-2);
        }
    }
}
